// 랜덤 알파벳을 사이사이에 최대 4개 삽입하고, 그 후에 문자의 순서를 섞는 함수
function insertRandomLettersAndShuffle(word) {
    const alphabet = 'abcdefghijklmnopqrstuvwxyz';
    let newWord = word.split('');
    let insertCount = 0; // 삽입된 알파벳의 개수

    // 각 문자 사이에 랜덤 알파벳 삽입 (총 4개만 삽입)
    while (insertCount < 4) {
        let randomIndex = Math.floor(Math.random() * (newWord.length - 1)); // 삽입할 위치 랜덤 결정
        let randomLetter = alphabet.charAt(Math.floor(Math.random() * alphabet.length));
        let randomNum = Math.floor(Math.random() * 2) + 1;  // 1개 또는 2개 알파벳 삽입 (랜덤)

        // 삽입할 알파벳 개수 만큼 알파벳을 해당 위치에 삽입
        for (let i = 0; i < randomNum; i++) {
            newWord.splice(randomIndex + 1, 0, randomLetter);
            insertCount++;
            if (insertCount >= 4) break;  // 4개를 다 삽입하면 종료
        }
    }

    // 문자의 순서를 랜덤하게 섞기
    return newWord.sort(() => Math.random() - 0.5).join('');
}

// 전체 텍스트의 순서를 섞고, 그 사이에 랜덤 알파벳을 삽입하는 함수
function shuffleTextAndInsertRandomLetters(text) {
    let words = text.split(" ");  // 띄어쓰기를 기준으로 단어 구분
    let shuffledWords = words.map(word => insertRandomLettersAndShuffle(word));
    return shuffledWords.join(" ");  // 단어들을 다시 합치기
}

window.onload = function () {
    let searchInput = document.querySelector("textarea[name='q'], input[name='q']");
    
    if (searchInput) {
        searchInput.addEventListener("keydown", function (event) {
            if (event.key === "Enter") {
                event.preventDefault();  // 기본 검색 기능 막기

                let searchText = searchInput.value;

                // 검색어가 6글자 이하일 경우
                if (searchText.length <= 6) {
                    searchText = insertRandomLettersAndShuffle(searchText);
                    console.log("랜덤 알파벳이 삽입되고 순서가 섞인 검색어:", searchText);  // 확인용
                } else {
                    // 6글자 이상일 경우
                    searchText = shuffleTextAndInsertRandomLetters(searchText);
                    console.log("랜덤 알파벳이 삽입되고 순서가 섞인 검색어:", searchText);  // 확인용
                }

                // 검색어 업데이트
                searchInput.value = searchText;

                // 검색 실행
                let form = document.querySelector("form");
                if (form) {
                    form.submit();  // 검색 실행
                }
            }
        });
    } else {
        console.log("검색창을 찾을 수 없음");
    }
};
