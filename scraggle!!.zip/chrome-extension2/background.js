let clickCount = 300;

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ clickCount });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'decrementClick') {
    clickCount--;
    chrome.storage.local.set({ clickCount });
  } else if (message.type === 'getClickCount') {
    sendResponse(clickCount);
  }
});
