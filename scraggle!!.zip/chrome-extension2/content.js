let isModalVisible = false;
let timer = 60;
let timerInterval;
let modal;
let showModalNextClick = false; // 100% 확률로 모달이 뜨도록 설정하는 플래그
let clickCount = 300;  // 우클릭 카운트

function startTimer() {
  timerInterval = setInterval(() => {
    if (isModalVisible) {
      timer--;  
      if (timer <= 0) {
        resetTimer();
        setNextClickToShowModal();  
      } else {
        updateTimerDisplay();  
      }
    }
  }, 1000);
}

function resetTimer() {
  clearInterval(timerInterval);
  timer = 60;
  clickCount = 300;  // 클릭 횟수도 초기화
  updateTimerDisplay();  
  startTimer();  

  hideModal();
  showModalNextClick = true;
}

function updateTimerDisplay() {
  if (modal) {
    const timerElement = modal.querySelector('#timer');
    if (timerElement) {
      timerElement.innerHTML = `남은 시간: ${timer}초`;
    }
  }
}

function setNextClickToShowModal() {
  document.addEventListener('click', () => {
    if (showModalNextClick) {
      showModal();
    }
  }, { once: true });
}

function showModal() {
  if (isModalVisible) return;

  const screenWidth = window.screen.width;
  const screenHeight = window.screen.height;

  modal = document.createElement('div');
  modal.id = 'custom-modal';
  modal.style.position = 'fixed';
  modal.style.top = '0';
  modal.style.left = '0';
  modal.style.width = `${screenWidth}px`;
  modal.style.height = `${screenHeight}px`;
  modal.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
  modal.style.display = 'flex';
  modal.style.flexDirection = 'column';
  modal.style.justifyContent = 'center';
  modal.style.alignItems = 'center';
  modal.style.color = 'white';
  modal.style.fontSize = '24px';

  const timerDisplay = document.createElement('div');
  timerDisplay.id = 'timer';
  timerDisplay.style.marginBottom = '20px';
  timerDisplay.innerHTML = `남은 시간: ${timer}초`;

  const clickCountDisplay = document.createElement('div');
  clickCountDisplay.id = 'click-count';
  clickCountDisplay.innerHTML = `남은 우클릭 횟수: ${clickCount}`;

  modal.appendChild(timerDisplay);
  modal.appendChild(clickCountDisplay);
  document.body.appendChild(modal);
  isModalVisible = true;

  document.addEventListener('click', preventClick, true);
  document.addEventListener('mousedown', preventClick, true);
  document.addEventListener('mouseup', preventClick, true);
  document.addEventListener('contextmenu', handleRightClick);

  window.addEventListener('keydown', preventKeyDown, true);
  window.addEventListener('keypress', preventKeyDown, true);
  window.addEventListener('keyup', preventKeyDown, true);

  window.addEventListener('beforeunload', preventUnload);

  document.body.style.overflow = 'hidden';
  document.documentElement.style.overflow = 'hidden';

  if (document.documentElement.requestFullscreen) {
    document.documentElement.requestFullscreen();
  } else if (document.documentElement.mozRequestFullScreen) { 
    document.documentElement.mozRequestFullScreen();
  } else if (document.documentElement.webkitRequestFullscreen) { 
    document.documentElement.webkitRequestFullscreen();
  }

  window.addEventListener('keydown', preventEscAndAltTab);

  document.body.style.cursor = 'none';
  window.addEventListener('mousemove', lockCursorToBottom);
}

function lockCursorToBottom(event) {
  const screenWidth = window.screen.width;
  const screenHeight = window.screen.height;

  const cursorX = event.clientX;
  const cursorY = event.clientY;

  const lockedX = Math.min(screenWidth / 2, cursorX);
  const lockedY = Math.max(screenHeight - 4, cursorY);

  if (cursorY < screenHeight / 2) {
    event.preventDefault();
    window.scrollTo(lockedX, lockedY);
  } else {
    window.scrollTo(lockedX, lockedY);
  }

  document.documentElement.style.cursor = 'none';
  document.body.style.cursor = 'none';
}

function hideModal() {
  const modal = document.getElementById('custom-modal');
  if (modal) {
    modal.remove();
  }
  isModalVisible = false;

  document.removeEventListener('click', preventClick, true);
  document.removeEventListener('mousedown', preventClick, true);
  document.removeEventListener('mouseup', preventClick, true);
  document.removeEventListener('contextmenu', handleRightClick);

  window.removeEventListener('keydown', preventKeyDown, true);
  window.removeEventListener('keypress', preventKeyDown, true);
  window.removeEventListener('keyup', preventKeyDown, true);

  window.removeEventListener('beforeunload', preventUnload);
  window.removeEventListener('keydown', preventEscAndAltTab);

  document.body.style.overflow = '';
  document.documentElement.style.overflow = '';

  document.body.style.cursor = '';  // 커서 보이게 설정
  document.documentElement.style.cursor = '';  // 추가로 문서 전체에서도 보이도록 설정

  if (document.exitFullscreen) {
    document.exitFullscreen();
  } else if (document.mozCancelFullScreen) { 
    document.mozCancelFullScreen();
  } else if (document.webkitExitFullscreen) { 
    document.webkitExitFullscreen();
  }

  window.removeEventListener('mousemove', lockCursorToBottom); // 커서 고정 해제
}

function preventClick(event) {
  event.preventDefault();
  event.stopPropagation();
}

function handleRightClick(event) {
  clickCount--;

  if (clickCount <= 0) {
    hideModal();
    clickCount = 300;
  } else {
    const clickCountDisplay = document.querySelector('#click-count');
    if (clickCountDisplay) {
      clickCountDisplay.innerHTML = `우클릭 횟수: ${clickCount}`;
    }
  }

  event.preventDefault();
}

function preventKeyDown(event) {
  event.preventDefault();
  event.stopPropagation();
}

function preventUnload(event) {
  event.preventDefault();
  event.returnValue = '';
}

function preventEscAndAltTab(event) {
  if (event.key === 'Escape' || (event.altKey && event.key === 'Tab')) {
    event.preventDefault();
  }
}

document.addEventListener('click', () => {
  if (Math.random() < 0.2 && !showModalNextClick) {
    showModal();
  }
});

startTimer();
