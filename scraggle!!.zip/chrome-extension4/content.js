document.addEventListener("keydown", function(event) {
    if (event.key === "Backspace") {
        let randomChance = Math.random(); // 0.0 ~ 1.0 사이의 랜덤 값
        if (randomChance > 0.1) { // 90% 확률로 동작 차단
            event.preventDefault();
            console.log("백스페이스 입력이 차단되었습니다!");
        }
    }
});